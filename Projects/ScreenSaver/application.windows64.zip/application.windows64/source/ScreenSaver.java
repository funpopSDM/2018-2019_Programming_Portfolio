import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class ScreenSaver extends PApplet {

Lines[] line = new Lines[10];
int c;
float b;

public void setup() {
  c=5;
  background(255);
  
  //size(300, 300);
  for (int i=0; i<line.length; i++) {
    line[i] = new Lines(random(width), random(height), c, color(random(255), random(255), random(255)));
  }
}

public void draw() {  
  strokeWeight(random(0.1f, 3));
  if (frameCount>5000) {
    background(255);
    frameCount = 0;
  } else {
    for (int i=0; i<line.length; i++) {
      line[i].display();
    }
  }
}

public void mouseClicked() {
  saveFrame("line-######.png");
}
class Lines {
  //Class Variables
  float xpos, ypos, b, moveCount;
  int m;
  //Constructor
  Lines(float startX, float startY, float moveCount, int m) {
    this.xpos = startX;
    this.ypos = startY;
    this.moveCount = moveCount;
    this.m = m;
  }
  //Display
  public void display(){
    stroke(m);
      b=random(4);
    if (b<=1) {
      moveRight(xpos, ypos, moveCount);      
    } else {
      if (b<=2&&b>1) {
        moveLeft(xpos, ypos, moveCount);
      } else {
        if (b<=3&&b>2) {
          moveUp(xpos, ypos, moveCount);
        } else {
          if (b>3) {
            moveDown(xpos, ypos, moveCount);
          }
        }
      }
    }
  }

  //Movement

    /*----------------------------Directions-------------------------------*/
    //Right
    public void moveRight(float startX, float startY, float moveCount) {
      for (float i=0; i<moveCount; i++) {
        if (i+startX>width) {
          startX = 0;
        }
        point(startX+i, startY);
        xpos = startX + i;
      }
    }
    //Left
    public void moveLeft(float startX, float startY, float moveCount) {
      for (float i=0; i<moveCount; i++) {
        if (i+startX<0) {
          startX = width;
        }
        point(startX-i, startY);
        xpos = startX - i;
      }
    }

    //Up
    public void moveUp(float startX, float startY, float moveCount) {
      for (float i=0; i<moveCount; i++) {
        if (i+startY<0) {
          startY = height;
        }
        point(startX, startY-i);
        ypos = startY - i;
      }
    }

    //Down
    public void moveDown(float startX, float startY, float moveCount) {
      for (float i=0; i<moveCount; i++) {
        if (i+startY>height) {
          startY = 0;
        }
        point(startX, startY+i);
        ypos = startY + i;
      }
    }
}
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "ScreenSaver" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
