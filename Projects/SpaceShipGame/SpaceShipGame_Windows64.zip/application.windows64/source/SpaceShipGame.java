import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import processing.sound.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SpaceShipGame extends PApplet {

// Space Ship Game
// by Seth McCullough
// 2018
/* TO DO: Add Enemy Ship
 */

Table tResults;
TableRow tr1;

PlayerShip player;
ArrayList<Laser> lasers;
ArrayList<Rock> rocks;
ArrayList<EnemyShip> enemy;
EnemyShip e1;
Timer timer;

SoundFile laser;
SoundFile levelUp;

//For Ship's Thrust
float A, B, C;
//HUD
int score = 0;
int progress = 0;
int level = 1;
//Spawn
int enemySpawn;
int rockRate = 1000;
//Other
boolean gameOver = false;
boolean menu = true;
String name = "Funpop";


public void setup() {
  
  background(10, 0, 10);
  tResults = loadTable("results.csv", "header");
  player = new PlayerShip();
  lasers = new ArrayList<Laser>();
  rocks = new ArrayList<Rock>();
  enemy = new ArrayList<EnemyShip>();
  timer = new Timer(rockRate);
  //Sound FX
  laser = new SoundFile(this, "laser.wav");
  levelUp = new SoundFile(this, "levelUp.wav");
}

public void draw() {
  A = random(6, 8);
  B = random(34, 36);
  C = random(50, 60);
  rockRate = 1000-level;
  background(10, 0, 10);

  if (gameOver) {
    menu = true;
  }

  if (menu) {
    startScreen();
  } else {

    // HUD
    fill(75);
    quad(0, height, width, height, width*.9f, height-70, width*.1f, height-70);

    // Timer
    if (!gameOver) {
      if (timer.isFinished()) {
        rocks.add(new Rock(PApplet.parseInt(random(width)), -50, 50, 50, 0xff5e4932, 0xff7c6043, 1+level/10));
        timer.start();
      }
    }

    //Progress
    if (progress >= 100) {
      level += 1;
      enemySpawn += 1;
      progress = 0;
      levelUp.play();
    }
    // Spawn Enemy Ship
    if (enemySpawn>=10) {
      enemy.add(new EnemyShip(width/2, -20, 100, 2));
      enemySpawn = 0;
    }

    // Add/Remove Lasers 
    for (int i = 0; i<lasers.size(); i++) {
      lasers.get(i).fire();
      lasers.get(i).display();
      if (lasers.get(i).reachedTop()) {
        lasers.remove(i);
      }
    }

    // Add/Remove Rocks
    for (int i = 0; i<rocks.size(); i++) {
      rocks.get(i).move();
      rocks.get(i).display();
      if (rocks.get(i).reachedBottom()) {
        rocks.get(i).y =-20;
      }
      // Collision Detection--------------
      for (int j=0; j<lasers.size(); j++) {
        if (dist(lasers.get(j).x, lasers.get(j).y, rocks.get(i).x, rocks.get(i).y) < rocks.get(i).r) {
          progress += 10;
          score += 100;
          rocks.get(i).health -= 10;
          lasers.remove(lasers.get(j));
        }
      }
      if (dist(mouseX, mouseY, rocks.get(i).x, rocks.get(i).y) < rocks.get(i).r+player.r) {
        rocks.get(i).health -= 100;
        player.health -= 10;
      }
      if (rocks.get(i).health < 1) {
        rocks.remove(rocks.get(i));
      }
    }

    if (!gameOver) {
      player.display(mouseX, mouseY, A, B, C);
      if (player.health <= 0) {
        gameOver = true;
      }
    }


    //Text
    updateDisplay();
  }
}

public void mousePressed() {
  lasers.add(new Laser(mouseX, mouseY-50, 7, 30, 0xffbc0000, 0xfffc2100, 10, false));
  laser.amp(0.3f);
  laser.play();
}

public void updateDisplay() {
  textSize(20);
  fill(255);
  textAlign(CENTER);
  text(player.health + "%", width/2, height-20);
  text(score, width/4, 45);
  text(level, width/2, 45);
  text(progress + "%", width/1.3f, 45);
  text("Health", width/2, height-45);
  text("Score", width/4, 20);
  text("Level", width/2, 20);
  text("Progress", width/1.3f, 20);
}

public void startScreen() {
  background(10, 0, 10);
  textAlign(CENTER);
  rectMode(CENTER);
  if (gameOver) {
    fill(200, 0, 0);
    textSize(80);
    text("GAME OVER", width/2, height/2);
    textSize(30);
    fill(255);
    text("Your Score: " + score, width/2, 30);
    text("Level: " + level, width/2, 60);
  } else {
    fill(0, 255, 0);
    textSize(60);
    text("Space Adventure", width/2, height/2);
  }
  fill(0, 255, 0);
  rect(width/2, height-50, 200, 50);
  textSize(20);
  fill(0);
  text("Click to Play", width/2, height-47);
  fill(255);
  TableRow newRow = tResults.addRow();
  newRow.setString("NAME", name);
  newRow.setString("SCORE", str(score));
  newRow.setString("LEVEL", str(level));
  saveTable(tResults, "data/results.csv");

  tResults.sort("SCORE");
  tr1 = tResults.getRow(tResults.getRowCount()-1);
  text("High Score: " + name + "   " + tr1.getString("SCORE"), width/2, height/2+140);
  text("Level: " + tr1.getString("LEVEL"), width/2, height/2+165);
}

public void mouseReleased() {
  menu = false;
  gameOver = false;
}
class EnemyShip {
  /*----------------------Variables-------------------------*/
  int x, y, liv;
  float A, B, C, r, health, speed;
  int c1, c2, c3;
  boolean alive;
  /*----------------------Constructor-----------------------*/
  EnemyShip(int x, int y, int health, float speed){
    this.x = x;
    this.y = y;
    this.health=health;
    this.speed=speed;
    health = 100;
    speed = 1;
    alive = true;
  }

  /*----------------------Display---------------------------*/
public void display(){
ellipse(200,200,20,20);
}
  /*----------------------Function--------------------------*/
}
class Laser {
  /*-------------Variable--------------------*/
  int x, y, w, h;
  int c1, c2;
  float damage, speed;
  boolean active, reachedTop, enemy;
  /*-------------Constructor-----------------*/
  Laser(int x, int y, int w, int h, int c1, int c2, float speed, boolean enemy) {
    this.x=x;
    this.y=y;
    this.w=w;
    this.h=h;
    this.c1=c1;
    this.c2=c2;
    this.speed=speed;
    this.enemy = enemy;
    active=true;
  }
  /*-------------Display---------------------*/
  public void display() {
    noStroke();
    fill(c1);
    ellipseMode(CENTER);
    ellipse(x, y, w, h);
    fill(c2);
    ellipse(x, y, w/2, h/1.2f);
  }
  /*-------------Functions-------------------*/
  public void fire() {
    if (!enemy) {
      y -= speed;
    }
  }
  public boolean reachedTop() {
    if (y < -50) {
      return true;
    } else {
      return false;
    }
  }
}
class PlayerShip {
  /*----------------------Variables-------------------------*/
  int x, y, liv, health;
  float A, B, C, r, speed;
  int c1, c2, c3;
  boolean alive;
  /*----------------------Constructor-----------------------*/
  PlayerShip(){
    //this.x = x;
    //this.y = y;
    //this.A = A;
    //this.B = B;
    //this.C = C;
    r = 40;
    health = 100;
    speed = 5;
    alive = true;
  }

  /*----------------------Display---------------------------*/
  public void display(int x, int y, float A, float B, float C){
    //Wing Tips (lighter color of wing)
    fill(180, 0, 0);
    noStroke();  
    quad(x-10, y-60, x-10, y-40, x-17, y-30, x-30, y-30);
    quad(x+10, y-60, x+10, y-40, x+17, y-30, x+30, y-30);  
    rect(x-30, y-30, 13, 30);  
    rect(x+17, y-30, 13, 30);
    
    //Body
    fill(150, 0, 0);
    ellipse(x, y-5, 20, 40);
    
    //Cockpit
    fill(0, 200, 255);
    ellipse(x, y-10, 10, 20);
    
    //Wing Back (Darker color of wing)
    fill(150, 0, 0);
    quad(x-17, y, x-10, y+20, x-20, y+20, x-40, y-10);
    quad(x+17, y, x+10, y+20, x+20, y+20, x+40, y-10);
    
    //Back
    fill(180, 0, 0);
    rect(x-20, y+10, 40, 10);
    
    //Thrust
    fill(0, 200, 255);
    quad(x+16, y+27, x+11, y+27, x+A, y+B, x+A+13, y+B);
    quad(x-16, y+27, x-11, y+27, x-A, y+B, x-A-13, y+B);
    triangle(x+17, y+27, x+10, y+27, x+13.5f, y+C);
    triangle(x-17, y+27, x-10, y+27, x-13.5f, y+C);
    
    //Booster Engines
    fill(130);
    ellipse(x+13, y+15, 15, 30);
    ellipse(x-13, y+15, 15, 30);
    fill(180);
    rect(x+25, y-30, 5, 20);
    rect(x-30, y-30, 5, 20);
    stroke(1);
    line(x-7, y+20, x-20, y+20);
    line(x+6, y+20, x+19, y+20);
    line(x-7, y+10, x-20, y+10);
    line(x+6, y+10, x+19, y+10);
    fill(100);
    ellipse(x+13, y+15, 10, 20);
    ellipse(x-14, y+15, 10, 20);
  }
  /*----------------------Function--------------------------*/

}
class PowerUp {
int x, y, type;










}
class Rock {
/*-------------Variable--------------------*/
  int x, y, w, h, r;
  int c1, c2;
  float health,speed;
  boolean alive;
/*-------------Constructor-----------------*/  
  Rock(int x,int y,int w,int h,int c1,int c2,float speed){
  this.x=x;
  this.y=y;
  this.w=w;
  this.h=h;
  this.c1=c1;
  this.c2=c2;
  this.speed=speed;
  alive=true;
  health = 10;
  r = w/2;
  }
/*-------------Display---------------------*/
  public void display(){
  rectMode(CENTER);
  fill(c1);
  rect(x,y,w,h);
  stroke(0);
  line(x-w/2,y-h/2,x+w/2,y+h/2);
  line(x-w/2,y+h/2,x+w/2,y-h/2);
  fill(c2);
  rect(x,y,w/1.7f,h/1.7f);
  rectMode(CORNER);
  }
/*-------------Functions-------------------*/
public void move(){
  y += speed;
  }
    public boolean reachedBottom() {
    if (y > height+100) {
      return true;
    } else {
      return false;
    }
  }
}
class Timer {

  int savedTime; // When Timer started
  int totalTime; // How long Timer should last

  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }

  // Starting the timer
  public void start() {
    // When the timer starts it stores the current time in milliseconds.
    savedTime = millis();
  }

  // The function isFinished() returns true if 5,000 ms have passed. 
  // The work of the timer is farmed out to this method.
  public boolean isFinished() { 
    // Check how much time has passed
    int passedTime = millis()- savedTime;
    if (passedTime > totalTime) {
      return true;
    } else {
      return false;
    }
  }
}
  public void settings() {  size(500, 500); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SpaceShipGame" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
